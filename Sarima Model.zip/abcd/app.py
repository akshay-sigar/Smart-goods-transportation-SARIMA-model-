from flask import Flask
from flask import Flask, render_template, redirect, url_for, request
import warnings
import itertools
import numpy as np
import matplotlib.pyplot as plt
warnings.filterwarnings("ignore")
plt.style.use('fivethirtyeight')
import pandas as pd
import statsmodels.api as sm
import matplotlib
import datetime
from pylab import rcParams
from datetime import datetime


matplotlib.rcParams['axes.labelsize'] = 18
matplotlib.rcParams['xtick.labelsize'] = 16
matplotlib.rcParams['ytick.labelsize'] = 16
matplotlib.rcParams['text.color'] = 'k'

app = Flask(__name__)

@app.route('/')
def index():
  return render_template('index.html')


@app.route('/vv')
def vv():
		now = datetime.now()
		x = now.strftime("%H")
		x=int(x)
		y=(x+1)%24
		m=datetime.today().year
		n=datetime.today().month
		o=datetime.today().day
		x = datetime(m,n,o,x,0,0)
		x=x.strftime("%H:00:00")
		t = datetime(m,n,o,y,0,0)
		t=t.strftime("%H:00:00")
		df = pd.read_csv("C:/Users/owner/Desktop/abcd/data/VVAP.csv", parse_dates=['created_at'] ,index_col='created_at').between_time(x,t)
		df=df['field5']
		y = df.resample('10min').mean().ffill()
		print(y)
		decomposition = sm.tsa.seasonal_decompose(y,freq=5, model='additive')
		p = d = q = range(0, 2)
		pdq = list(itertools.product(p, d, q))
		seasonal_pdq = [(x[0], x[1], x[2], 12)
		for x in list(itertools.product(p, d, q))]

		print('Examples of parameter combinations for Seasonal ARIMA...')
		print('SARIMAX: {} x {}'.format(pdq[1], seasonal_pdq[1]))
		print('SARIMAX: {} x {}'.format(pdq[1], seasonal_pdq[2]))
		print('SARIMAX: {} x {}'.format(pdq[2], seasonal_pdq[3]))
		print('SARIMAX: {} x {}'.format(pdq[2], seasonal_pdq[4]))
		mod = sm.tsa.statespace.SARIMAX(y,
										order=(1, 1, 1),
										seasonal_order=(1, 1, 0, 12),
										enforce_stationarity=False,
										enforce_invertibility=False)

		results = mod.fit()

		print(results.summary().tables[1])
		pred = results.get_prediction(start=pd.to_datetime('2019-05-1'), dynamic=False)
		pred_ci = pred.conf_int()
		y_forecasted = pred.predicted_mean
		y_truth = y['2018-05-01':]
		pred = results.get_prediction(start=pd.to_datetime('2019-05-1'), dynamic=False)
		pred_ci = pred.conf_int()

		ax = y['2018':].plot(label='observed')
		pred.predicted_mean.plot(ax=ax, label='One-step ahead Forecast', alpha=.7, figsize=(14, 7))

		ax.fill_between(pred_ci.index,
						pred_ci.iloc[:, 0],
						pred_ci.iloc[:, 1], color='k', alpha=.2)

				
		plt.xlabel("Date")
		plt.ylabel("AQI")
		plt.legend()
		fig1 = plt.gcf()
		fig1.savefig('C:/Users/owner/Desktop/abcd/static/vvc.png',dpi=300)
		
		pred = results.get_prediction(start=pd.to_datetime('2019-05-1'), dynamic=False)
		pred_ci = pred.conf_int()
		ax = y['2019-05-01':].plot(label='observed')
		ax=pred.predicted_mean.plot(label='One-step ahead Forecast', alpha=.7, figsize=(10,6))
		plt.xlabel("Date")
		plt.ylabel("AQI")
		plt.legend()
		
		

		# Compute the mean square error
		mse = ((y_forecasted - y_truth) ** 2).mean()
		print('The Mean Squared Error of our forecasts is {}'.format(round(mse, 2)))
		print('The Root Mean Squared Error of our forecasts is {}'.format(round(np.sqrt(mse), 2)))
		pred_uc = results.get_forecast(steps=1)
		pred_ci = pred_uc.conf_int()
		pred1=pred_ci.iloc[:,1]
		pred2=pred_ci.iloc[:,0]
		x=len(pred_ci)
		for i in range(x):
				pred_ci.iloc[i,0]=(pred_ci.iloc[i,0]+pred_ci.iloc[i,1])/2
		Y=pred_ci.iloc[:,0].values
		for i in range(len(Y)):
			if (Y[i] <= 50):
				value="Good Contidition"
			elif ((Y[i]<=100)  &  (Y[i]>50)):
				value="Satisfactory Contidition"
			elif ((Y[i]>100)  &  (Y[i]<=200)):
				value="Moderate Contidition"
			elif ((Y[i]>200)  &  (Y[i]<=300) ):
				value="Poor Contidition"
			elif ((Y[i]>300)  &  (Y[i]<=400)):
				value="Very Poor Contidition"
			elif(Y[i]>400):
				value="Severe Contidition"
		b=value
		c=Y[0]
		pred_uc = results.get_forecast(steps=10)
		pred_ci = pred_uc.conf_int()
		print(pred_ci)
		ax = y.plot(label='observed', figsize=(20, 10))
		pred_uc.predicted_mean.plot(ax=ax, label='Forecast')
		ax.fill_between(pred_ci.index,
						pred_ci.iloc[:, 0],
						pred_ci.iloc[:, 1], color='k', alpha=.25)
				
		plt.xlabel("Date")
		plt.ylabel("AQI")	

		plt.legend()
		fig2 = plt.gcf()
		fig2.savefig('C:/Users/owner/Desktop/abcd/static/vvp.png',dpi=300)
	
		print(pred_ci)
		return render_template('ab.html',pred1=b,pred2=c,url1='/static/vvc.png',url2='/static/vvp.png')	

	
@app.route('/sion')
def sion():
		now = datetime.now()
		x = now.strftime("%H")
		x=int(x)
		y=(x+1)%24
		m=datetime.today().year
		n=datetime.today().month
		o=datetime.today().day
		x = datetime(m,n,o,x,0,0)
		x=x.strftime("%H:00:00")
		t = datetime(m,n,o,y,0,0)
		t=t.strftime("%H:00:00")
		df = pd.read_csv("C:/Users/owner/Desktop/abcd/data/SionAP.csv", parse_dates=['created_at'] ,index_col='created_at').between_time(x,t)
		df=df['field5']
		y = df.resample('10min').mean().ffill()
		print(y)
		decomposition = sm.tsa.seasonal_decompose(y,freq=20, model='additive')
		p = d = q = range(0, 2)
		pdq = list(itertools.product(p, d, q))
		seasonal_pdq = [(x[0], x[1], x[2], 12)
		for x in list(itertools.product(p, d, q))]

		print('Examples of parameter combinations for Seasonal ARIMA...')
		print('SARIMAX: {} x {}'.format(pdq[1], seasonal_pdq[1]))
		print('SARIMAX: {} x {}'.format(pdq[1], seasonal_pdq[2]))
		print('SARIMAX: {} x {}'.format(pdq[2], seasonal_pdq[3]))
		print('SARIMAX: {} x {}'.format(pdq[2], seasonal_pdq[4]))
		mod = sm.tsa.statespace.SARIMAX(y,
										order=(1, 1, 1),
										seasonal_order=(1, 1, 0, 12),
										enforce_stationarity=False,
										enforce_invertibility=False)

		results = mod.fit()

		print(results.summary().tables[1])
		pred = results.get_prediction(start=pd.to_datetime('2019-05-1'), dynamic=False)
		pred_ci = pred.conf_int()
		y_forecasted = pred.predicted_mean
		y_truth = y['2018-05-01':]
		pred = results.get_prediction(start=pd.to_datetime('2019-05-1'), dynamic=False)
		pred_ci = pred.conf_int()

		ax = y['2018':].plot(label='observed')
		pred.predicted_mean.plot(ax=ax, label='One-step ahead Forecast', alpha=.7, figsize=(14, 7))

		ax.fill_between(pred_ci.index,
						pred_ci.iloc[:, 0],
						pred_ci.iloc[:, 1], color='k', alpha=.2)

		ax.set_xlabel('Date')

		plt.xlabel("Date")
		plt.ylabel("AQI")
		plt.legend()
		fig1 = plt.gcf()
		fig1.savefig('C:/Users/owner/Desktop/abcd/static/sionc.png',dpi=300)
	
		# Compute the mean square error
		mse = ((y_forecasted - y_truth) ** 2).mean()
		print('The Mean Squared Error of our forecasts is {}'.format(round(mse, 2)))
		print('The Root Mean Squared Error of our forecasts is {}'.format(round(np.sqrt(mse), 2)))
		pred_uc = results.get_forecast(steps=1)
		pred_ci = pred_uc.conf_int()
		x=len(pred_ci)
		for i in range(x):
				pred_ci.iloc[i,0]=(pred_ci.iloc[i,0]+pred_ci.iloc[i,1])/2
		Y=pred_ci.iloc[:,0].values
		for i in range(len(Y)):
			if (Y[i] <= 50):
				value="Good Contidition"
			elif ((Y[i]<=100)  &  (Y[i]>50)):
				value="Satisfactory Contidition"
			elif ((Y[i]>100)  &  (Y[i]<=200)):
				value="Moderate Contidition"
			elif ((Y[i]>200)  &  (Y[i]<=300) ):
				value="Poor Contidition"
			elif ((Y[i]>300)  &  (Y[i]<=400)):
				value="Very Poor Contidition"
			elif(Y[i]>400):
				value="Severe Contidition"
		b=value
		c=Y[0]
		pred_uc = results.get_forecast(steps=10)
		pred_ci = pred_uc.conf_int()
		print(pred_ci)
		ax = y.plot(label='observed', figsize=(20, 10))
		pred_uc.predicted_mean.plot(ax=ax, label='Forecast')
		ax.fill_between(pred_ci.index,
						pred_ci.iloc[:, 0],
						pred_ci.iloc[:, 1], color='k', alpha=.25)
				
		plt.xlabel("Date")
		plt.ylabel("AQI")

		plt.legend()
		fig2 = plt.gcf()
		fig2.savefig('C:/Users/owner/Desktop/abcd/static/sionp.png',dpi=300)
	
		print(pred_ci)		
		return render_template('ab.html',len=len(pred),pred1=b,pred2=c,url1='/static/sionc.png',url2='/static/sionp.png')	

@app.route('/thane')
def thane():
		now = datetime.now()
		x = now.strftime("%H")
		x=int(x)
		y=(x+1)%24
		m=datetime.today().year
		n=datetime.today().month
		o=datetime.today().day
		x = datetime(m,n,o,x,0,0)
		x=x.strftime("%H:00:00")
		t = datetime(m,n,o,y,0,0)
		t=t.strftime("%H:00:00")
		df = pd.read_csv("C:/Users/owner/Desktop/abcd/data/ThaneAP.csv", parse_dates=['created_at'] ,index_col='created_at').between_time(x,t)
		df=df['field5']
		y = df.resample('10min').mean().ffill()
		print(y)
		decomposition = sm.tsa.seasonal_decompose(y,freq=20, model='additive')
		p = d = q = range(0, 2)
		pdq = list(itertools.product(p, d, q))
		seasonal_pdq = [(x[0], x[1], x[2], 12)
		for x in list(itertools.product(p, d, q))]

		print('Examples of parameter combinations for Seasonal ARIMA...')
		print('SARIMAX: {} x {}'.format(pdq[1], seasonal_pdq[1]))
		print('SARIMAX: {} x {}'.format(pdq[1], seasonal_pdq[2]))
		print('SARIMAX: {} x {}'.format(pdq[2], seasonal_pdq[3]))
		print('SARIMAX: {} x {}'.format(pdq[2], seasonal_pdq[4]))
		mod = sm.tsa.statespace.SARIMAX(y,
										order=(1, 1, 1),
										seasonal_order=(1, 1, 0, 12),
										enforce_stationarity=False,
										enforce_invertibility=False)

		results = mod.fit()

		print(results.summary().tables[1])
		pred = results.get_prediction(start=pd.to_datetime('2019-05-1'), dynamic=False)
		pred_ci = pred.conf_int()
		y_forecasted = pred.predicted_mean
		y_truth = y['2018-05-01':]
		pred = results.get_prediction(start=pd.to_datetime('2019-05-1'), dynamic=False)
		pred_ci = pred.conf_int()

		ax = y['2018':].plot(label='observed')
		pred.predicted_mean.plot(ax=ax, label='One-step ahead Forecast', alpha=.7, figsize=(14, 7))

		ax.fill_between(pred_ci.index,
						pred_ci.iloc[:, 0],
						pred_ci.iloc[:, 1], color='k', alpha=.2)

				
		plt.xlabel("Date")
		plt.ylabel("AQI")
		plt.legend()
		fig1 = plt.gcf()
		fig1.savefig('C:/Users/owner/Desktop/abcd/static/thanec.png',dpi=300)
	
		# Compute the mean square error
		mse = ((y_forecasted - y_truth) ** 2).mean()
		print('The Mean Squared Error of our forecasts is {}'.format(round(mse, 2)))
		print('The Root Mean Squared Error of our forecasts is {}'.format(round(np.sqrt(mse), 2)))
		pred_uc = results.get_forecast(steps=1)
		pred_ci = pred_uc.conf_int()
		x=len(pred_ci)
		for i in range(x):
				pred_ci.iloc[i,0]=(pred_ci.iloc[i,0]+pred_ci.iloc[i,1])/2
		Y=pred_ci.iloc[:,0].values
		for i in range(len(Y)):
			if (Y[i] <= 50):
				value="Good Contidition"
			elif ((Y[i]<=100)  &  (Y[i]>50)):
				value="Satisfactory Contidition"
			elif ((Y[i]>100)  &  (Y[i]<=200)):
				value="Moderate Contidition"
			elif ((Y[i]>200)  &  (Y[i]<=300) ):
				value="Poor Contidition"
			elif ((Y[i]>300)  &  (Y[i]<=400)):
				value="Very Poor Contidition"
			elif(Y[i]>400):
				value="Severe Contidition"
		b=value
		c=Y[0]
		pred_uc = results.get_forecast(steps=10)
		pred_ci = pred_uc.conf_int()
		print(pred_ci)
		ax = y.plot(label='observed', figsize=(20, 10))
		pred_uc.predicted_mean.plot(ax=ax, label='Forecast')
		ax.fill_between(pred_ci.index,
						pred_ci.iloc[:, 0],
						pred_ci.iloc[:, 1], color='k', alpha=.25)
		
		plt.xlabel("Date")
		plt.ylabel("AQI")	

		plt.legend()
		fig2 = plt.gcf()
		fig2.savefig('C:/Users/owner/Desktop/abcd/static/thanep.png',dpi=300)
	
		print(pred_ci)		
		return render_template('ab.html',pred1=b,pred2=c,url1='/static/thanec.png',url2='/static/thanep.png')	

if __name__ =='__main__':
	app.run(debug=True)